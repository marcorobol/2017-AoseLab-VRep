package unitn.aose.warehousesim.api;

public class LoadUnloadArea {

}
