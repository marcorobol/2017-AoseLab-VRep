package unitn.aose.warehousesim.api;

public enum MovementState {
	
	stop, running, approaching, waiting;
	
}
