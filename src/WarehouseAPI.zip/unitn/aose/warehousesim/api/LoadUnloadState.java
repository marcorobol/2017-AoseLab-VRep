package unitn.aose.warehousesim.api;

public enum LoadUnloadState {
	
	unloaded, loaded, loading, unloading;
	
}
