package unitn.aose.warehousesim.api;

public class Rail {

}
