package unitn.aose.warehousesim.api;

public interface IMovementFSM {
	
	MovementState getState();
	
	void continueMoving();
	void stopHere();
	
	void registerListener(IMovementListener listener);
	void unregisterListener(IMovementListener listener);
	
}
